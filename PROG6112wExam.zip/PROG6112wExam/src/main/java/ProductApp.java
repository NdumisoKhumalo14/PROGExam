import javax.swing.*;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {

    private final JTextField txtName = new JTextField(15);
    private final JComboBox<String> cboProduct = new JComboBox<>(
            new String[]{"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});
    private final JTextField txtPrice = new JTextField(15);

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 5, 5));

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");
        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem clearItem = new JMenuItem("Clear");
        exitItem.addActionListener(e -> System.exit(0));
        clearItem.addActionListener(e -> {
            txtName.setText("");
            txtPrice.setText("");
        });
        fileMenu.add(exitItem);
        editMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        setJMenuBar(menuBar);

        JButton btnProcess = new JButton("PROCESS");
        btnProcess.addActionListener(e -> processSale());

        add(new JLabel("Customer Name:"));
        add(txtName);
        add(new JLabel("Select Product:"));
        add(cboProduct);
        add(new JLabel("Enter Price:"));
        add(txtPrice);
        add(new JLabel());
        add(btnProcess);

        setSize(450, 220);
        setLocationRelativeTo(null);
    }

    private void processSale() {
        try {
            String name = txtName.getText().trim();
            String product = (String) cboProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText().trim());

            IProductCalculations calc = new ProductCalculations(price);

            String details = "Customer Name: " + name
                    + "\nProduct: " + product
                    + "\nVAT: R " + calc.GetVat()
                    + "\nCOMMISSION: R " + calc.GetCommission()
                    + "\nTOTAL: R " + calc.GetTotal();

            JOptionPane.showMessageDialog(this, details);

            try (PrintWriter out = new PrintWriter(new FileWriter("data.txt"))) {
                out.println("DATA LOG");
                out.println("********************************");
                out.println(details);
                out.println("********************************");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save to data.txt");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }

    private static class ProductCalculations implements IProductCalculations {

        public ProductCalculations(double price) {
        }

        @Override
        public double GetVat() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public double GetCommission() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public double GetTotal() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}