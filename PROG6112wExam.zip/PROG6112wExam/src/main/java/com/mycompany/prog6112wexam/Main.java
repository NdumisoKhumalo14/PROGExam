package com.mycompany.prog6112wexam;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        String[] names = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = new int[3][3];
        Scanner input = new Scanner(System.in);
        for (int i = 0; i <names.length; i++) {
            for (int m = 0; m <3; m++){
                System.out.print("Enter Number of sales for month "+ (m+1)
                        + "for" + names [i] + names[i] + "mattress:");
                sales[i][m] = input.nextInt();
            }
            System.out.println("Product Sales Report");
            
            PrintProduct printer = new PrintProduct (new Product (names, sales));
            printer.PrintTotalProductSales();
            printer.PrintAverageProductSles();
            printer.PrintMostPopularProduct();
        }
                    
            
            
            
                       
            }
        }
