
public interface IProduct {
   int GetTtoalProductsSold ();
   double GetAverageProductsSold();
   String GetMostPopularProduct();

    public String GetTotalProductsSold();
}
