import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProductTest {

    private final Product product = new Product(
            new String[]{"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"},
            new int[][]{{25, 18, 20}, {15, 10, 12}, {18, 15, 20}});

    @BeforeAll
    public static void setUpClass() throws Exception {
    }

    @AfterAll
    public static void tearDownClass() throws Exception {
    }

    @BeforeEach
    public void setUp() throws Exception {
    }

    @AfterEach
    public void tearDown() throws Exception {
    }

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(153, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(17.0, product.GetAverageProductSold(), 0.001);
    }

    /**
     * Test of GetTtoalProductsSold method, of class Product.
     */
    @Test
    public void testGetTtoalProductsSold() {
        System.out.println("GetTtoalProductsSold");
        Product instance = null;
        int expResult = 0;
        int result = instance.GetTtoalProductsSold();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAverageProductsSold method, of class Product.
     */
    @Test
    public void testGetAverageProductsSold() {
        System.out.println("GetAverageProductsSold");
        Product instance = null;
        double expResult = 0.0;
        double result = instance.GetAverageProductsSold();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetMostPopularProduct method, of class Product.
     */
    @Test
    public void testGetMostPopularProduct() {
        System.out.println("GetMostPopularProduct");
        Product instance = null;
        String expResult = "";
        String result = instance.GetMostPopularProduct();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}