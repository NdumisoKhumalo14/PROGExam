
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductCalculationsTest {
    
    public ProductCalculationsTest() {
    }
    
   @Test
   public void GetTotal_WithValidDta_ReturnsCorrectValue() {
       assertEquals(4200.0, calc.GetTtoal(), 0.001);
   }